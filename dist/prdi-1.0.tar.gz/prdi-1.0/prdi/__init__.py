from .BinomialDistribution import Gaussian
from .GaussianDistribution import Binomial

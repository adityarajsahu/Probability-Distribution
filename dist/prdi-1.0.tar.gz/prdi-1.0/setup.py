from setuptools import setup

setup(name='prdi',
      version='1.0',
      description='Binomial and Gaussian Distributions',
      packages=['prdi'],
      author='Adityaraj Sahu',
      author_email='119MM0944@nitrkl.ac.in',
      zip_safe=False)
